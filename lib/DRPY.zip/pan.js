require("./util.js");
require("./ali.js");
require("./quark.js");
require("./alist_share.js");
require("./tvbox_share.js");

var __panDetailError = ""

function initPan() {
  const alist_share_switch = getBoolStorage("alist_share_switch") || getBoolStorage("alist_share_quark_switch") || !isNewAPP()
  if (alist_share_switch) {
    initAlistShare();
    initTVBoxShare();
  }
  initAli();
  initQuark();
}

function panDetailContent(vod, ids) {
  ids = ids.filter((item, index, array) => array.indexOf(item) === index);
  const froms = [];
  const urls = [];
  var isAddAli = false, isAddQuark = false, isAddPikpak = false, isAddUC = false, isAdd115 = false, allowAddMulti = true;
  for (const shareUrl of ids) {
      if (froms.length >= 6) {
          break;
      }
      const aliShareData = getAliShareData(shareUrl);
      const quarkShareData = getQuarkShareData(shareUrl);
      const ucShareData = getUCShareData(shareUrl);
      const p115ShareData = get115ShareData(shareUrl);
      const pikpakShareData = getPikpakShareData(shareUrl);
      var tvboxInit = canTVBoxInit();
      var alistInit = canAlistInit();
      if (aliShareData && (!isAddAli || allowAddMulti)) {
        const alist_share_switch = getBoolStorage("alist_share_switch") || !isNewAPP()
        if ((tvboxInit || alistInit) && alist_share_switch) {
          const vods = tvboxInit ? tvboxDetailContent(vod, aliShareData, 0) : alistDetailContent(vod, aliShareData, 0)
          if(vods.tabs) {
              isAddAli = true;
          }
          froms.push(...vods.tabs);
          urls.push(...vods.lists);
        }else{
          const vods = aliDetailContent(vod, aliShareData)
          if(vods.tabs) {
              isAddAli = true;
          }
          froms.push(...vods.tabs);
          urls.push(...vods.lists);
        }
      }else if (quarkShareData && (!isAddQuark || allowAddMulti)) {
          const alist_share_switch = getBoolStorage("alist_share_quark_switch") || !isNewAPP()
          if ((tvboxInit || alistInit) && alist_share_switch) {
            const vods = tvboxInit ? tvboxDetailContent(vod, quarkShareData, 5) : alistDetailContent(vod, quarkShareData, 5)
            if(vods.tabs) {
                isAddQuark = true;
            }
            froms.push(...vods.tabs);
            urls.push(...vods.lists);
          } else {
            const vods = quarkDetailContent(vod, quarkShareData)
            if(vods.tabs) {
                isAddQuark = true;
            }
            froms.push(...vods.tabs);
            urls.push(...vods.lists);
          }
      }else if ((tvboxInit || alistInit) && shareUrl.includes("mypikpak.com/s/") && (!isAddPikpak || allowAddMulti)) {
          const vods = tvboxInit ? tvboxDetailContent(vod, pikpakShareData, 1) : alistDetailContent(vod, pikpakShareData, 1)
          if(vods.tabs) {
              isAddPikpak = true;
          }
          froms.push(...vods.tabs);
          urls.push(...vods.lists);
      }else if ((tvboxInit || alistInit) && shareUrl.includes("drive.uc.cn/s/") && (!isAddUC || allowAddMulti)) {
          const vods = tvboxInit ? tvboxDetailContent(vod, ucShareData, 7) : alistDetailContent(vod, ucShareData, 7)
          if(vods.tabs) {
              isAddUC = true;
          }
          froms.push(...vods.tabs);
          urls.push(...vods.lists);
      }else if ((tvboxInit || alistInit) && shareUrl.includes("115.com/s/") && (!isAdd115 || allowAddMulti)) {
          const vods = tvboxInit ? tvboxDetailContent(vod, p115ShareData, 8) : alistDetailContent(vod, p115ShareData, 8)
          if(vods.tabs) {
              isAdd115 = true;
          }
          froms.push(...vods.tabs);
          urls.push(...vods.lists);
      }
  }
  if (ids.length > 0) {
    froms.push("分享链接");
    var items = [];
    for (let shareUrl of ids) {
      if (shareUrl.length) {
        var name = shareUrl;
        if (name.includes("aliyundrive.com") || name.includes("alipan.com")) {
          name = "阿里云盘"
        }else if (name.includes("quark.cn")) {
          name = "夸克网盘"
        }else if (name.includes("xunlei.com")) {
          name = "迅雷云盘"
        }else if (name.includes("baidu.com")) {
          name = "百度网盘"
        }else if (name.includes("drive.uc.cn")) {
            name = "UC网盘"
        }else if (name.includes("115.com")) {
            name = "115网盘"
        }else if (name.includes("mypikpak.com")) {
            name = "PikPak网盘"
        }else if (name.includes("139.com")) {
            name = "移动云盘"
        }
        items.push(name + "$" + shareUrl);
      }
    }
    urls.push(items);
  }
  return {
    tabs: froms,
    lists: urls,
    error: __panDetailError
  };
}

function panPlay(id, flag) {
  if (flag == "ERROR") {
    return {
      parse: 0,
      jx: 0,
      url: "",
      error: id ? id : "获取播放地址错误"
    }
  }
  if (flag.startsWith('Ali-')) {
    return aliPlay(id, flag);
  } else if (flag.startsWith('Quark-')) {
    return quarkPlay(id, flag)
  } else if (id.startsWith('1~~~')) {
    return tvboxPlay(id, flag)
  } else {
    return alistPlay(id, flag)
  }
}
