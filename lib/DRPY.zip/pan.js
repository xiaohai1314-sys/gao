require("./util.js");
require("./ali.js");
require("./quark.js");
require("./alist_share.js");

var __panDetailError = ""

function initPan() {
  const alist_share_switch = getBoolStorage("alist_share_switch") || !isNewAPP()
  if (alist_share_switch) {
    initAlistShare();
  }
  initAli();
  initQuark();
}

function panDetailContent(vod, ids) {
    ids = ids.filter((item, index, array) => array.indexOf(item) === index);
  const froms = [];
  const urls = [];
  for (const shareUrl of ids) {
      if (froms.length >= 2) {
          break;
      }
      const aliShareData = getAliShareData(shareUrl);
      const ucShareData = getUCShareData(shareUrl);
      const quarkShareData = getQuarkShareData(shareUrl);
      var alistInit = canAlistInit();
      if (aliShareData) {
        const alist_share_switch = getBoolStorage("alist_share_switch") || !isNewAPP()
        if (alistInit && alist_share_switch) {
          const vods = alistDetailContent(vod, aliShareData, 0)
          froms.push(...vods.tabs);
          urls.push(...vods.lists);
        }else{
          const vods = aliDetailContent(vod, aliShareData)
          froms.push(...vods.tabs);
          urls.push(...vods.lists);
        }
      }else if (quarkShareData) {
          const alist_share_switch = getBoolStorage("alist_share_quark_switch") || !isNewAPP()
          if (alistInit && alist_share_switch) {
            const vods = alistDetailContent(vod, quarkShareData, 5)
            froms.push(...vods.tabs);
            urls.push(...vods.lists);
          } else {
            const vods = quarkDetailContent(vod, quarkShareData)
            froms.push(...vods.tabs);
            urls.push(...vods.lists);
          }
      }else if (alistInit && shareUrl.includes("mypikpak.com/s/")) {
          const vods = alistDetailContent(vod, ucShareData, 1)
          froms.push(...vods.tabs);
          urls.push(...vods.lists);
      }else if (alistInit && shareUrl.includes("drive.uc.cn/s/")) {
          const vods = alistDetailContent(vod, ucShareData, 7)
          froms.push(...vods.tabs);
          urls.push(...vods.lists);
      }else if (alistInit && shareUrl.includes("115.com/s/")) {
          const vods = alistDetailContent(vod, ucShareData, 8)
          froms.push(...vods.tabs);
          urls.push(...vods.lists);
      }
  }
  if (ids.length > 0) {
    froms.push("分享链接");
    var items = [];
    for (let shareUrl of ids) {
      if (shareUrl.length) {
        var name = shareUrl;
        if (name.includes("aliyundrive.com") || name.includes("alipan.com")) {
          name = "阿里云盘"
        }else if (name.includes("quark.cn")) {
          name = "夸克网盘"
        }else if (name.includes("xunlei.com")) {
          name = "迅雷云盘"
        }else if (name.includes("baidu.com")) {
          name = "百度网盘"
        }else if (name.includes("drive.uc.cn")) {
            name = "UC网盘"
        }else if (name.includes("115.com")) {
            name = "115网盘"
        }else if (name.includes("mypikpak.com")) {
            name = "PikPak网盘"
        }
        items.push(name + "$" + shareUrl);
      }
    }
    urls.push(items);
  }
  return {
    tabs: froms,
    lists: urls,
    error: __panDetailError
  };
}

function panPlay(id, flag) {
  if (flag.startsWith('Ali-')) {
    return aliPlay(id, flag);
  } else if (flag.startsWith('Quark-')) {
    return quarkPlay(id, flag)
  } else {
    return alistPlay(id, flag)
  }
}
