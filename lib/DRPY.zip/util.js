
var http = function http(url) {
  var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
  if (options.method === "POST" && options.data) {
    options.body = JSON.stringify(options.data);
    options.headers = Object.assign({
      "content-type": "application/json"
    }, options.headers);
  }
  options.timeout = request_timeout;
  try {
    var res = req(url, options);
    res.json = function () {
      try {
        print(res.content)
        return res && res.content ? JSON.parse(res.content) : null;
      } catch (e) {
        return null;
      }
    };
    res.text = function () {
      return res && res.content ? res.content : "";
    };
    return res;
  } catch (e) {
    return {
      json: function json() {
        return null;
      },
      text: function text() {
        return "";
      }
    };
  }
};
["get", "post"].forEach(function (method) {
  http[method] = function (url) {
    var options = arguments.length > 1 && arguments[1] !== undefined ? arguments[1] : {};
    return http(url, Object.assign(options, {
      method: method.toUpperCase()
    }));
  };
});


function findBestLCS(mainItem, targetItems) {
  const results = [];
  let bestMatchIndex = 0;

  for (let i = 0; i < targetItems.length; i++) {
      const currentLCS = lcs(mainItem.name, targetItems[i].name);
      results.push({ target: targetItems[i], lcs: currentLCS });
      if (currentLCS.length > results[bestMatchIndex].lcs.length) {
          bestMatchIndex = i;
      }
  }

  const bestMatch = results[bestMatchIndex];

  return { allLCS: results, bestMatch: bestMatch, bestMatchIndex: bestMatchIndex };
}

function delay(ms) {
  const start = Date.now();
  while (Date.now() - start < ms) {}
  // return new Promise((resolve) => setTimeout(resolve, ms));
}

function showHUD(msg) {
  try {
    showHUD_b(msg);
  } catch (e) {
    print(e)
  }
}

function inputValue(key, describe) {
  try {
    inputValue_b(key, describe);
  } catch (e) {
    print(e)
  }
}

const localMap = new Map();
function getStorage(key) {
  try {
    return getStorage_b(key);
  } catch (e) {
    return localMap.get("ali", key);
    print(e)
  }
}

function setStorage(key, value) {
  try {
    setStorage_b(key, value);
  } catch (e) {
    localMap.set("ali", k, v);
    print(e)
  }
}

function getStorageDic(key) {
  let valueStr = getStorage(key)
  if (valueStr) {
    let value = JSON.parse(valueStr);
    return value;
  }
  return null
}

function setDicStorage(key, value) {
  let valueStr = JSON.stringify(value);
  setStorage(key, valueStr);
}
function getBoolStorage(key) {
  let valueStr = getStorage(key)
  if (valueStr === "1") {
    return true;
  }
  return false
}
function setBoolStorage(key, value) {
  setStorage(key, (value ? "1" : "0"));
}

/**
 * 字符串相似度匹配
 * @returns
 */
function lcs(str1, str2) {
  if (!str1 || !str2) {
      return {
          length: 0,
          sequence: '',
          offset: 0,
      };
  }

  var sequence = '';
  var str1Length = str1.length;
  var str2Length = str2.length;
  var num = new Array(str1Length);
  var maxlen = 0;
  var lastSubsBegin = 0;

  for (var i = 0; i < str1Length; i++) {
      var subArray = new Array(str2Length);
      for (var j = 0; j < str2Length; j++) {
          subArray[j] = 0;
      }
      num[i] = subArray;
  }
  var thisSubsBegin = null;
  for (i = 0; i < str1Length; i++) {
      for (j = 0; j < str2Length; j++) {
          if (str1[i] !== str2[j]) {
              num[i][j] = 0;
          } else {
              if (i === 0 || j === 0) {
                  num[i][j] = 1;
              } else {
                  num[i][j] = 1 + num[i - 1][j - 1];
              }

              if (num[i][j] > maxlen) {
                  maxlen = num[i][j];
                  thisSubsBegin = i - num[i][j] + 1;
                  if (lastSubsBegin === thisSubsBegin) {
                      // if the current LCS is the same as the last time this block ran
                      sequence += str1[i];
                  } else {
                      // this block resets the string builder if a different LCS is found
                      lastSubsBegin = thisSubsBegin;
                      sequence = ''; // clear it
                      sequence += str1.substr(lastSubsBegin, i + 1 - lastSubsBegin);
                  }
              }
          }
      }
  }
  return {
      length: maxlen,
      sequence: sequence,
      offset: thisSubsBegin,
  };
}


function levenshteinDistance(str1, str2) {
  return 100 - 100 * (0, distance)(str1, str2) / Math.max(str1.length, str2.length);
}
function get_size(sz) {
  if (sz <= 0) {
    return "";
  }
  var filesize = "";
  if (sz > 1024 * 1024 * 1024 * 1024) {
    sz /= 1024 * 1024 * 1024 * 1024;
    filesize = "TB";
  } else if (sz > 1024 * 1024 * 1024) {
    sz /= 1024 * 1024 * 1024;
    filesize = "GB";
  } else if (sz > 1024 * 1024) {
    sz /= 1024 * 1024;
    filesize = "MB";
  } else if (sz > 1024) {
    sz /= 1024;
    filesize = "KB";
  } else {
    filesize = "B";
  }
  var sizeStr = sz.toFixed(2) + filesize,
    index = sizeStr.indexOf("."),
    dou = sizeStr.substr(index + 1, 2);
  if (dou === "00") {
    return sizeStr.substring(0, index) + sizeStr.substr(index + 3, 2);
  } else {
    return sizeStr;
  }
}


function hasChinese(text) {
  var reg = /[\u4e00-\u9fa5]/;
  return reg.test(text);
}

function episodeNameTrim(text) {
  var name = text.replace(/玩偶哥.*【神秘的哥哥们】/g, '');
    name = name.replace(/\.(?:mp4|avi|mkv)$/i, '');
  return name;
}

function decodeBase64(str) {
  var keyStr = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=";
  var output = "";
  var chr1, chr2, chr3;
  var enc1, enc2, enc3, enc4;
  var i = 0;

  str = str.replace(/[^A-Za-z0-9+/=]/g, "");

  while (i < str.length) {
      enc1 = keyStr.indexOf(str.charAt(i++));
      enc2 = keyStr.indexOf(str.charAt(i++));
      enc3 = keyStr.indexOf(str.charAt(i++));
      enc4 = keyStr.indexOf(str.charAt(i++));

      chr1 = (enc1 << 2) | (enc2 >> 4);
      chr2 = ((enc2 & 15) << 4) | (enc3 >> 2);
      chr3 = ((enc3 & 3) << 6) | enc4;

      output += String.fromCharCode(chr1);

      if (enc3 !== 64) {
          output += String.fromCharCode(chr2);
      }
      if (enc4 !== 64) {
          output += String.fromCharCode(chr3);
      }
  }

  return output;
}

function isNewAPP() {
  try {
    getStorage_b("versions");
      return true
  } catch (e) {
      return false
  }
}


function generateUUID() {
    var chars = '0123456789abcdef';
    var uuid = '';
    for (var i = 0; i < 36; i++) {
        var char = '';
        if (i === 8 || i === 13 || i === 18 || i === 23) {
            char = '-';
        } else if (i === 14) {
            char = '4'; // UUID version 4
        } else if (i === 19) {
            char = chars.substr(Math.floor(Math.random() * 4) + 8, 1); // 8, 9, a, or b
        } else {
            char = chars.substr(Math.floor(Math.random() * 16), 1);
        }
        uuid += char;
    }
    return uuid;
}
